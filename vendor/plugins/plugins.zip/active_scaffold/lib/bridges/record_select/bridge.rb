ActiveScaffold.bridge "RecordSelect" do
  install do
    require File.join(File.dirname(__FILE__), "lib/record_select_bridge.rb")
  end
end
