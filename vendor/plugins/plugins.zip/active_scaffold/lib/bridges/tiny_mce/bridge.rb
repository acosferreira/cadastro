ActiveScaffold.bridge "TinyMCE" do
  install do
    require File.join(File.dirname(__FILE__), "lib/tiny_mce_bridge.rb")
  end
end
