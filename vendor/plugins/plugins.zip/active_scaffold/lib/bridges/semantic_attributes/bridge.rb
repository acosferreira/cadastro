ActiveScaffold.bridge "SemanticAttributes" do
  install do
    require File.join(File.dirname(__FILE__), "lib/semantic_attributes_bridge.rb")
  end
end
